import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  filesToUpload: Array<File> = [];

  constructor(private dataService:DataService) { }

  ngOnInit() {
  }

  upload() {
    const formData = new FormData();
    const files: Array<File> = this.filesToUpload;
    
    if(files.length ==0){
      alert("Please select file to upload..!")
      return;
    }

    for(let i =0; i < files.length; i++){
        formData.append("uploads[]", files[i], files[i]['name']);
    }
    console.log('form data variable :   '+ formData.toString());

    this.dataService.uploadFile(formData).
        subscribe(result => {
          //alert("Message: "+ result.message);          
          console.log(result);
        })
   
}

fileChangeEvent(fileInput: any) {
    this.filesToUpload = <Array<File>>fileInput.target.files; 
}

}
