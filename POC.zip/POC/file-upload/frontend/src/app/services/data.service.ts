import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private httpClient:HttpClient) { }

 uploadFile(formData){
  return this.httpClient.post('http://localhost:3003/api/upload', formData)  
 }

}
