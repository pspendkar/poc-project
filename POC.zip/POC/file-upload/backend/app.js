var express = require('express');
var multer = require('multer');
var bodyParser=require('body-parser');
var path = require('path');
var app = express();
var port = 3003;

var fs = require('fs');
var mongoose = require('mongoose');
let conn = mongoose.connection;
var Gridfs = require('gridfs-stream');
Gridfs.mongo = mongoose.mongo;
let gfs;  

mongoose.Promise = global.Promise;
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

conn.once("open", () => {
    gfs = Gridfs(conn.db);
  });

 var dbURI = process.env.DB_LINK || "mongodb://localhost:27017/testgridfs"   
    mongoose.connect(dbURI)
      .then(() => {
          console.log(`[*] Connected to Database`);
      })
      .catch(err => {
          console.log(`[*] Error while connecting to DB, with error: ${err}`)
      }); 
 

// specify the folder
app.use(express.static(path.join(__dirname, 'uploads')));
// headers and content type
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header('Access-Control-Allow-Methods','GET,PUT,POST,DELETE')
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  next();
});

var storage = multer.diskStorage({    
    destination: function (req, file, cb) {
      cb(null, './uploads/')
    },
    filename: function (req, file, cb) {
      cb(null, file.originalname);
    }
  });

  var upload = multer({ storage: storage });

 app.post('/api/upload', upload.array('uploads[]', 12), (req, res,next) => {
        
        //console.log('files', req.files);
        for(var i=0;i<req.files.length;i++){         
          let part = req.files[i];
        
        var filesrc = path.join(__dirname, part.path);        

        let writeStream = gfs.createWriteStream({
            filename: 'file_' + part.filename,
            mode: 'w',
            content_type: part.mimetype
        });
        
        fs.createReadStream(filesrc).pipe(writeStream);

        fs.unlink(filesrc);

        writeStream.on('close', (file) => {          
          if(!file) {
            res.status(400).send('No file received');
          }          
            return res.status(200).send({
                message: 'Success',
                file: file
            });            
        });
        } 
    });

  app.get('/api/read',(req,res)=>{
    fs.createReadStream('./meistersinger.mp3').
    pipe(bucket.openUploadStream('meistersinger.mp3')).
    on('error', function(error) {
      assert.ifError(error);
    }).
    on('finish', function() {
      console.log('done!');
      process.exit(0);
    });
  });

  var server = app.listen(port, function () {
    console.log("Listening on port %s...", port);
  });