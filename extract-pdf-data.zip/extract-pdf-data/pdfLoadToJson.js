
const childProcess = require('child_process');
const path = require('path');
var parseString = require('xml2js').parseString;
const pdfExtract = require('./pdfExtract.js').pdfExtract;
var fs = require('fs');



const promise = pdfExtract.run("./resource/spring-eform.pdf")
      .then((results) => {
        
        parseString(results[0].data, function (err, result) {
          //console.dir(JSON.stringify(result));


          fs.writeFile("./resource/spring-eform-data.json", JSON.stringify(result), function (err) {
            if (err) console.log("Error with saving...." + err);
            console.log('Saved!');
          });


        });
        
});