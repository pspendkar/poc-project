#demo extract-pdf-data

1. Exports Spring e form to Json.
2. Input will be file "./resource/spring-eform.pdf".
3. Output will be saved at "./resource/spring-eform-data.json".
4. Commands to run the project
        npm install
        node pdfLoadToJson
5. Sample output is availabe at ./resource folder.
6. As per our findings it looks the spring e form is XFA form.("XML Forms Architecture").
7. In order to read this file. We will use this application.
